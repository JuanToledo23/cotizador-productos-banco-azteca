import { Component } from '@angular/core';

@Component({
    selector: 'dialog-presupuesto',
    templateUrl: 'dialogPresupuesto.html',
    styleUrls: ['dialogSurtir.component.scss']
})

export class DialogPresupuesto {
  constructor() { }
   
}
