import {Component} from '@angular/core';

@Component({
    selector: 'dialog-DatosGenerales',
    templateUrl: 'dialogDatosGenerales.html',
    styleUrls: ['ticketsAbarrotes.component.scss'],
})
export class DialogDatosGenerales {
    
}